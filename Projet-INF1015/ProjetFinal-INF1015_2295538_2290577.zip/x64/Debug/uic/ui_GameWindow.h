/********************************************************************************
** Form generated from reading UI file 'GameWindow.ui'
**
** Created by: Qt User Interface Compiler version 6.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GAMEWINDOW_H
#define UI_GAMEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>
#include "Case.hpp"

QT_BEGIN_NAMESPACE

class Ui_GameWindowClass
{
public:
    QWidget *centralWidget;
    QLabel *BoardImg;
    QLabel *gameHider;
    QLabel *GameTitle;
    QPushButton *CommencerButton;
    QPushButton *QuitterButton;
    QWidget *gridLayoutWidget;
    QGridLayout *plateauLayout;
    Case *g7;
    Case *a6;
    Case *c3;
    Case *d4;
    Case *e8;
    Case *h7;
    Case *e6;
    Case *a3;
    Case *g4;
    Case *f6;
    Case *h4;
    Case *g2;
    Case *g1;
    Case *g3;
    Case *b3;
    Case *b7;
    Case *d6;
    Case *d2;
    Case *d8;
    Case *f1;
    Case *b2;
    Case *f3;
    Case *f8;
    Case *e3;
    Case *a1;
    Case *d3;
    Case *c1;
    Case *b8;
    Case *g5;
    Case *g6;
    Case *f5;
    Case *c6;
    Case *g8;
    Case *e5;
    Case *f4;
    Case *f2;
    Case *h1;
    Case *e4;
    Case *h6;
    Case *c7;
    Case *b1;
    Case *c4;
    Case *e1;
    Case *e7;
    Case *a4;
    Case *c5;
    Case *b6;
    Case *e2;
    Case *a2;
    Case *d5;
    Case *c8;
    Case *b4;
    Case *b5;
    Case *d7;
    Case *h8;
    Case *h5;
    Case *f7;
    Case *h3;
    Case *a5;
    Case *a7;
    Case *h2;
    Case *d1;
    Case *c2;
    Case *a8;
    QLabel *CompteurTour;
    QPushButton *PartieNormaleButton;
    QLabel *StatusLabel;
    QLabel *posLabel;
    QPushButton *posRandomButton;
    QPushButton *posRandomButton2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *GameWindowClass)
    {
        if (GameWindowClass->objectName().isEmpty())
            GameWindowClass->setObjectName("GameWindowClass");
        GameWindowClass->resize(1180, 895);
        GameWindowClass->setStyleSheet(QString::fromUtf8(""));
        GameWindowClass->setToolButtonStyle(Qt::ToolButtonStyle::ToolButtonTextOnly);
        centralWidget = new QWidget(GameWindowClass);
        centralWidget->setObjectName("centralWidget");
        BoardImg = new QLabel(centralWidget);
        BoardImg->setObjectName("BoardImg");
        BoardImg->setGeometry(QRect(120, 20, 700, 700));
        BoardImg->setPixmap(QPixmap(QString::fromUtf8("images/Board.png")));
        BoardImg->setScaledContents(true);
        gameHider = new QLabel(centralWidget);
        gameHider->setObjectName("gameHider");
        gameHider->setEnabled(true);
        gameHider->setGeometry(QRect(-210, -320, 2000, 2000));
        gameHider->setMinimumSize(QSize(0, 0));
        gameHider->setStyleSheet(QString::fromUtf8("background:black;"));
        GameTitle = new QLabel(centralWidget);
        GameTitle->setObjectName("GameTitle");
        GameTitle->setGeometry(QRect(230, 130, 521, 211));
        GameTitle->setStyleSheet(QString::fromUtf8("color:white;\n"
"font-family:sans-serif;\n"
"font: 75px courier new;\n"
""));
        GameTitle->setAlignment(Qt::AlignmentFlag::AlignCenter);
        CommencerButton = new QPushButton(centralWidget);
        CommencerButton->setObjectName("CommencerButton");
        CommencerButton->setGeometry(QRect(320, 440, 309, 25));
        QFont font;
        font.setFamilies({QString::fromUtf8("courier new")});
        font.setBold(false);
        font.setItalic(false);
        CommencerButton->setFont(font);
        CommencerButton->setStyleSheet(QString::fromUtf8("color:white;font:15px courier new; background:black;"));
        QuitterButton = new QPushButton(centralWidget);
        QuitterButton->setObjectName("QuitterButton");
        QuitterButton->setGeometry(QRect(320, 490, 309, 25));
        QuitterButton->setStyleSheet(QString::fromUtf8("color:white;font:15px courier new;background:black;"));
        gridLayoutWidget = new QWidget(centralWidget);
        gridLayoutWidget->setObjectName("gridLayoutWidget");
        gridLayoutWidget->setGeometry(QRect(120, 20, 701, 701));
        plateauLayout = new QGridLayout(gridLayoutWidget);
        plateauLayout->setSpacing(0);
        plateauLayout->setContentsMargins(11, 11, 11, 11);
        plateauLayout->setObjectName("plateauLayout");
        plateauLayout->setSizeConstraint(QLayout::SizeConstraint::SetNoConstraint);
        plateauLayout->setContentsMargins(0, 0, 0, 0);
        g7 = new Case(gridLayoutWidget);
        g7->setObjectName("g7");
        QSizePolicy sizePolicy(QSizePolicy::Policy::Ignored, QSizePolicy::Policy::MinimumExpanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(g7->sizePolicy().hasHeightForWidth());
        g7->setSizePolicy(sizePolicy);
        g7->setStyleSheet(QString::fromUtf8("background:transparent;"));
        g7->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(g7, 1, 6, 1, 1);

        a6 = new Case(gridLayoutWidget);
        a6->setObjectName("a6");
        sizePolicy.setHeightForWidth(a6->sizePolicy().hasHeightForWidth());
        a6->setSizePolicy(sizePolicy);
        a6->setStyleSheet(QString::fromUtf8("background:transparent;"));
        a6->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(a6, 2, 0, 1, 1);

        c3 = new Case(gridLayoutWidget);
        c3->setObjectName("c3");
        sizePolicy.setHeightForWidth(c3->sizePolicy().hasHeightForWidth());
        c3->setSizePolicy(sizePolicy);
        c3->setStyleSheet(QString::fromUtf8("background:transparent;"));
        c3->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(c3, 6, 2, 1, 1);

        d4 = new Case(gridLayoutWidget);
        d4->setObjectName("d4");
        sizePolicy.setHeightForWidth(d4->sizePolicy().hasHeightForWidth());
        d4->setSizePolicy(sizePolicy);
        d4->setStyleSheet(QString::fromUtf8("background:transparent;"));
        d4->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(d4, 5, 3, 1, 1);

        e8 = new Case(gridLayoutWidget);
        e8->setObjectName("e8");
        sizePolicy.setHeightForWidth(e8->sizePolicy().hasHeightForWidth());
        e8->setSizePolicy(sizePolicy);
        e8->setStyleSheet(QString::fromUtf8("background:transparent;"));
        e8->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(e8, 0, 4, 1, 1);

        h7 = new Case(gridLayoutWidget);
        h7->setObjectName("h7");
        sizePolicy.setHeightForWidth(h7->sizePolicy().hasHeightForWidth());
        h7->setSizePolicy(sizePolicy);
        h7->setStyleSheet(QString::fromUtf8("background:transparent;"));
        h7->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(h7, 1, 8, 1, 1);

        e6 = new Case(gridLayoutWidget);
        e6->setObjectName("e6");
        sizePolicy.setHeightForWidth(e6->sizePolicy().hasHeightForWidth());
        e6->setSizePolicy(sizePolicy);
        e6->setStyleSheet(QString::fromUtf8("background:transparent;"));
        e6->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(e6, 2, 4, 1, 1);

        a3 = new Case(gridLayoutWidget);
        a3->setObjectName("a3");
        sizePolicy.setHeightForWidth(a3->sizePolicy().hasHeightForWidth());
        a3->setSizePolicy(sizePolicy);
        a3->setStyleSheet(QString::fromUtf8("background:transparent;"));
        a3->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(a3, 6, 0, 1, 1);

        g4 = new Case(gridLayoutWidget);
        g4->setObjectName("g4");
        sizePolicy.setHeightForWidth(g4->sizePolicy().hasHeightForWidth());
        g4->setSizePolicy(sizePolicy);
        g4->setStyleSheet(QString::fromUtf8("background:transparent;"));
        g4->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(g4, 5, 6, 1, 1);

        f6 = new Case(gridLayoutWidget);
        f6->setObjectName("f6");
        sizePolicy.setHeightForWidth(f6->sizePolicy().hasHeightForWidth());
        f6->setSizePolicy(sizePolicy);
        f6->setStyleSheet(QString::fromUtf8("background:transparent;"));
        f6->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(f6, 2, 5, 1, 1);

        h4 = new Case(gridLayoutWidget);
        h4->setObjectName("h4");
        sizePolicy.setHeightForWidth(h4->sizePolicy().hasHeightForWidth());
        h4->setSizePolicy(sizePolicy);
        h4->setStyleSheet(QString::fromUtf8("background:transparent;"));
        h4->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(h4, 5, 8, 1, 1);

        g2 = new Case(gridLayoutWidget);
        g2->setObjectName("g2");
        sizePolicy.setHeightForWidth(g2->sizePolicy().hasHeightForWidth());
        g2->setSizePolicy(sizePolicy);
        g2->setStyleSheet(QString::fromUtf8("background:transparent;"));
        g2->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(g2, 7, 6, 1, 1);

        g1 = new Case(gridLayoutWidget);
        g1->setObjectName("g1");
        sizePolicy.setHeightForWidth(g1->sizePolicy().hasHeightForWidth());
        g1->setSizePolicy(sizePolicy);
        g1->setStyleSheet(QString::fromUtf8("background:transparent;"));
        g1->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(g1, 8, 6, 1, 1);

        g3 = new Case(gridLayoutWidget);
        g3->setObjectName("g3");
        sizePolicy.setHeightForWidth(g3->sizePolicy().hasHeightForWidth());
        g3->setSizePolicy(sizePolicy);
        g3->setStyleSheet(QString::fromUtf8("background:transparent;"));
        g3->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(g3, 6, 6, 1, 1);

        b3 = new Case(gridLayoutWidget);
        b3->setObjectName("b3");
        sizePolicy.setHeightForWidth(b3->sizePolicy().hasHeightForWidth());
        b3->setSizePolicy(sizePolicy);
        b3->setStyleSheet(QString::fromUtf8("background:transparent;"));
        b3->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(b3, 6, 1, 1, 1);

        b7 = new Case(gridLayoutWidget);
        b7->setObjectName("b7");
        sizePolicy.setHeightForWidth(b7->sizePolicy().hasHeightForWidth());
        b7->setSizePolicy(sizePolicy);
        b7->setStyleSheet(QString::fromUtf8("background:transparent;"));
        b7->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(b7, 1, 1, 1, 1);

        d6 = new Case(gridLayoutWidget);
        d6->setObjectName("d6");
        sizePolicy.setHeightForWidth(d6->sizePolicy().hasHeightForWidth());
        d6->setSizePolicy(sizePolicy);
        d6->setStyleSheet(QString::fromUtf8("background:transparent;"));
        d6->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(d6, 2, 3, 1, 1);

        d2 = new Case(gridLayoutWidget);
        d2->setObjectName("d2");
        sizePolicy.setHeightForWidth(d2->sizePolicy().hasHeightForWidth());
        d2->setSizePolicy(sizePolicy);
        d2->setStyleSheet(QString::fromUtf8("background:transparent;"));
        d2->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(d2, 7, 3, 1, 1);

        d8 = new Case(gridLayoutWidget);
        d8->setObjectName("d8");
        sizePolicy.setHeightForWidth(d8->sizePolicy().hasHeightForWidth());
        d8->setSizePolicy(sizePolicy);
        d8->setStyleSheet(QString::fromUtf8("background:transparent;"));
        d8->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(d8, 0, 3, 1, 1);

        f1 = new Case(gridLayoutWidget);
        f1->setObjectName("f1");
        sizePolicy.setHeightForWidth(f1->sizePolicy().hasHeightForWidth());
        f1->setSizePolicy(sizePolicy);
        f1->setStyleSheet(QString::fromUtf8("background:transparent;"));
        f1->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(f1, 8, 5, 1, 1);

        b2 = new Case(gridLayoutWidget);
        b2->setObjectName("b2");
        sizePolicy.setHeightForWidth(b2->sizePolicy().hasHeightForWidth());
        b2->setSizePolicy(sizePolicy);
        b2->setStyleSheet(QString::fromUtf8("background:transparent;"));
        b2->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(b2, 7, 1, 1, 1);

        f3 = new Case(gridLayoutWidget);
        f3->setObjectName("f3");
        sizePolicy.setHeightForWidth(f3->sizePolicy().hasHeightForWidth());
        f3->setSizePolicy(sizePolicy);
        f3->setStyleSheet(QString::fromUtf8("background:transparent;"));
        f3->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(f3, 6, 5, 1, 1);

        f8 = new Case(gridLayoutWidget);
        f8->setObjectName("f8");
        sizePolicy.setHeightForWidth(f8->sizePolicy().hasHeightForWidth());
        f8->setSizePolicy(sizePolicy);
        f8->setStyleSheet(QString::fromUtf8("background:transparent;"));
        f8->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(f8, 0, 5, 1, 1);

        e3 = new Case(gridLayoutWidget);
        e3->setObjectName("e3");
        sizePolicy.setHeightForWidth(e3->sizePolicy().hasHeightForWidth());
        e3->setSizePolicy(sizePolicy);
        e3->setStyleSheet(QString::fromUtf8("background:transparent;"));
        e3->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(e3, 6, 4, 1, 1);

        a1 = new Case(gridLayoutWidget);
        a1->setObjectName("a1");
        sizePolicy.setHeightForWidth(a1->sizePolicy().hasHeightForWidth());
        a1->setSizePolicy(sizePolicy);
        a1->setStyleSheet(QString::fromUtf8("background:transparent;"));
        a1->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(a1, 8, 0, 1, 1);

        d3 = new Case(gridLayoutWidget);
        d3->setObjectName("d3");
        sizePolicy.setHeightForWidth(d3->sizePolicy().hasHeightForWidth());
        d3->setSizePolicy(sizePolicy);
        d3->setStyleSheet(QString::fromUtf8("background:transparent;"));
        d3->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(d3, 6, 3, 1, 1);

        c1 = new Case(gridLayoutWidget);
        c1->setObjectName("c1");
        sizePolicy.setHeightForWidth(c1->sizePolicy().hasHeightForWidth());
        c1->setSizePolicy(sizePolicy);
        c1->setStyleSheet(QString::fromUtf8("background:transparent;"));
        c1->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(c1, 8, 2, 1, 1);

        b8 = new Case(gridLayoutWidget);
        b8->setObjectName("b8");
        sizePolicy.setHeightForWidth(b8->sizePolicy().hasHeightForWidth());
        b8->setSizePolicy(sizePolicy);
        b8->setStyleSheet(QString::fromUtf8("background:transparent;"));
        b8->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(b8, 0, 1, 1, 1);

        g5 = new Case(gridLayoutWidget);
        g5->setObjectName("g5");
        sizePolicy.setHeightForWidth(g5->sizePolicy().hasHeightForWidth());
        g5->setSizePolicy(sizePolicy);
        g5->setStyleSheet(QString::fromUtf8("background:transparent;"));
        g5->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(g5, 3, 6, 1, 1);

        g6 = new Case(gridLayoutWidget);
        g6->setObjectName("g6");
        sizePolicy.setHeightForWidth(g6->sizePolicy().hasHeightForWidth());
        g6->setSizePolicy(sizePolicy);
        g6->setStyleSheet(QString::fromUtf8("background:transparent;"));
        g6->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(g6, 2, 6, 1, 1);

        f5 = new Case(gridLayoutWidget);
        f5->setObjectName("f5");
        sizePolicy.setHeightForWidth(f5->sizePolicy().hasHeightForWidth());
        f5->setSizePolicy(sizePolicy);
        f5->setStyleSheet(QString::fromUtf8("background:transparent;"));
        f5->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(f5, 3, 5, 1, 1);

        c6 = new Case(gridLayoutWidget);
        c6->setObjectName("c6");
        sizePolicy.setHeightForWidth(c6->sizePolicy().hasHeightForWidth());
        c6->setSizePolicy(sizePolicy);
        c6->setStyleSheet(QString::fromUtf8("background:transparent;"));
        c6->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(c6, 2, 2, 1, 1);

        g8 = new Case(gridLayoutWidget);
        g8->setObjectName("g8");
        sizePolicy.setHeightForWidth(g8->sizePolicy().hasHeightForWidth());
        g8->setSizePolicy(sizePolicy);
        g8->setStyleSheet(QString::fromUtf8("background:transparent;"));
        g8->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(g8, 0, 6, 1, 1);

        e5 = new Case(gridLayoutWidget);
        e5->setObjectName("e5");
        sizePolicy.setHeightForWidth(e5->sizePolicy().hasHeightForWidth());
        e5->setSizePolicy(sizePolicy);
        e5->setStyleSheet(QString::fromUtf8("background:transparent;"));
        e5->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(e5, 3, 4, 1, 1);

        f4 = new Case(gridLayoutWidget);
        f4->setObjectName("f4");
        sizePolicy.setHeightForWidth(f4->sizePolicy().hasHeightForWidth());
        f4->setSizePolicy(sizePolicy);
        f4->setStyleSheet(QString::fromUtf8("background:transparent;"));
        f4->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(f4, 5, 5, 1, 1);

        f2 = new Case(gridLayoutWidget);
        f2->setObjectName("f2");
        sizePolicy.setHeightForWidth(f2->sizePolicy().hasHeightForWidth());
        f2->setSizePolicy(sizePolicy);
        f2->setStyleSheet(QString::fromUtf8("background:transparent;"));
        f2->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(f2, 7, 5, 1, 1);

        h1 = new Case(gridLayoutWidget);
        h1->setObjectName("h1");
        sizePolicy.setHeightForWidth(h1->sizePolicy().hasHeightForWidth());
        h1->setSizePolicy(sizePolicy);
        h1->setStyleSheet(QString::fromUtf8("background:transparent;"));
        h1->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(h1, 8, 8, 1, 1);

        e4 = new Case(gridLayoutWidget);
        e4->setObjectName("e4");
        sizePolicy.setHeightForWidth(e4->sizePolicy().hasHeightForWidth());
        e4->setSizePolicy(sizePolicy);
        e4->setStyleSheet(QString::fromUtf8("background:transparent;"));
        e4->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(e4, 5, 4, 1, 1);

        h6 = new Case(gridLayoutWidget);
        h6->setObjectName("h6");
        sizePolicy.setHeightForWidth(h6->sizePolicy().hasHeightForWidth());
        h6->setSizePolicy(sizePolicy);
        h6->setStyleSheet(QString::fromUtf8("background:transparent;"));
        h6->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(h6, 2, 8, 1, 1);

        c7 = new Case(gridLayoutWidget);
        c7->setObjectName("c7");
        sizePolicy.setHeightForWidth(c7->sizePolicy().hasHeightForWidth());
        c7->setSizePolicy(sizePolicy);
        c7->setStyleSheet(QString::fromUtf8("background:transparent;"));
        c7->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(c7, 1, 2, 1, 1);

        b1 = new Case(gridLayoutWidget);
        b1->setObjectName("b1");
        sizePolicy.setHeightForWidth(b1->sizePolicy().hasHeightForWidth());
        b1->setSizePolicy(sizePolicy);
        b1->setStyleSheet(QString::fromUtf8("background:transparent;"));
        b1->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(b1, 8, 1, 1, 1);

        c4 = new Case(gridLayoutWidget);
        c4->setObjectName("c4");
        sizePolicy.setHeightForWidth(c4->sizePolicy().hasHeightForWidth());
        c4->setSizePolicy(sizePolicy);
        c4->setStyleSheet(QString::fromUtf8("background:transparent;"));
        c4->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(c4, 5, 2, 1, 1);

        e1 = new Case(gridLayoutWidget);
        e1->setObjectName("e1");
        sizePolicy.setHeightForWidth(e1->sizePolicy().hasHeightForWidth());
        e1->setSizePolicy(sizePolicy);
        e1->setStyleSheet(QString::fromUtf8("background:transparent;"));
        e1->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(e1, 8, 4, 1, 1);

        e7 = new Case(gridLayoutWidget);
        e7->setObjectName("e7");
        sizePolicy.setHeightForWidth(e7->sizePolicy().hasHeightForWidth());
        e7->setSizePolicy(sizePolicy);
        e7->setStyleSheet(QString::fromUtf8("background:transparent;"));
        e7->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(e7, 1, 4, 1, 1);

        a4 = new Case(gridLayoutWidget);
        a4->setObjectName("a4");
        sizePolicy.setHeightForWidth(a4->sizePolicy().hasHeightForWidth());
        a4->setSizePolicy(sizePolicy);
        a4->setStyleSheet(QString::fromUtf8("background:transparent;"));
        a4->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(a4, 5, 0, 1, 1);

        c5 = new Case(gridLayoutWidget);
        c5->setObjectName("c5");
        sizePolicy.setHeightForWidth(c5->sizePolicy().hasHeightForWidth());
        c5->setSizePolicy(sizePolicy);
        c5->setStyleSheet(QString::fromUtf8("background:transparent;"));
        c5->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(c5, 3, 2, 1, 1);

        b6 = new Case(gridLayoutWidget);
        b6->setObjectName("b6");
        sizePolicy.setHeightForWidth(b6->sizePolicy().hasHeightForWidth());
        b6->setSizePolicy(sizePolicy);
        b6->setStyleSheet(QString::fromUtf8("background:transparent;"));
        b6->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(b6, 2, 1, 1, 1);

        e2 = new Case(gridLayoutWidget);
        e2->setObjectName("e2");
        sizePolicy.setHeightForWidth(e2->sizePolicy().hasHeightForWidth());
        e2->setSizePolicy(sizePolicy);
        e2->setStyleSheet(QString::fromUtf8("background:transparent;"));
        e2->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(e2, 7, 4, 1, 1);

        a2 = new Case(gridLayoutWidget);
        a2->setObjectName("a2");
        sizePolicy.setHeightForWidth(a2->sizePolicy().hasHeightForWidth());
        a2->setSizePolicy(sizePolicy);
        a2->setStyleSheet(QString::fromUtf8("background:transparent;"));
        a2->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(a2, 7, 0, 1, 1);

        d5 = new Case(gridLayoutWidget);
        d5->setObjectName("d5");
        sizePolicy.setHeightForWidth(d5->sizePolicy().hasHeightForWidth());
        d5->setSizePolicy(sizePolicy);
        d5->setStyleSheet(QString::fromUtf8("background:transparent;"));
        d5->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(d5, 3, 3, 1, 1);

        c8 = new Case(gridLayoutWidget);
        c8->setObjectName("c8");
        sizePolicy.setHeightForWidth(c8->sizePolicy().hasHeightForWidth());
        c8->setSizePolicy(sizePolicy);
        c8->setStyleSheet(QString::fromUtf8("background:transparent;"));
        c8->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(c8, 0, 2, 1, 1);

        b4 = new Case(gridLayoutWidget);
        b4->setObjectName("b4");
        sizePolicy.setHeightForWidth(b4->sizePolicy().hasHeightForWidth());
        b4->setSizePolicy(sizePolicy);
        b4->setStyleSheet(QString::fromUtf8("background:transparent;"));
        b4->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(b4, 5, 1, 1, 1);

        b5 = new Case(gridLayoutWidget);
        b5->setObjectName("b5");
        sizePolicy.setHeightForWidth(b5->sizePolicy().hasHeightForWidth());
        b5->setSizePolicy(sizePolicy);
        b5->setStyleSheet(QString::fromUtf8("background:transparent;"));
        b5->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(b5, 3, 1, 1, 1);

        d7 = new Case(gridLayoutWidget);
        d7->setObjectName("d7");
        sizePolicy.setHeightForWidth(d7->sizePolicy().hasHeightForWidth());
        d7->setSizePolicy(sizePolicy);
        d7->setStyleSheet(QString::fromUtf8("background:transparent;"));
        d7->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(d7, 1, 3, 1, 1);

        h8 = new Case(gridLayoutWidget);
        h8->setObjectName("h8");
        sizePolicy.setHeightForWidth(h8->sizePolicy().hasHeightForWidth());
        h8->setSizePolicy(sizePolicy);
        h8->setStyleSheet(QString::fromUtf8("background:transparent;"));
        h8->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(h8, 0, 8, 1, 1);

        h5 = new Case(gridLayoutWidget);
        h5->setObjectName("h5");
        sizePolicy.setHeightForWidth(h5->sizePolicy().hasHeightForWidth());
        h5->setSizePolicy(sizePolicy);
        h5->setStyleSheet(QString::fromUtf8("background:transparent;"));
        h5->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(h5, 3, 8, 1, 1);

        f7 = new Case(gridLayoutWidget);
        f7->setObjectName("f7");
        sizePolicy.setHeightForWidth(f7->sizePolicy().hasHeightForWidth());
        f7->setSizePolicy(sizePolicy);
        f7->setStyleSheet(QString::fromUtf8("background:transparent;"));
        f7->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(f7, 1, 5, 1, 1);

        h3 = new Case(gridLayoutWidget);
        h3->setObjectName("h3");
        sizePolicy.setHeightForWidth(h3->sizePolicy().hasHeightForWidth());
        h3->setSizePolicy(sizePolicy);
        h3->setStyleSheet(QString::fromUtf8("background:transparent;"));
        h3->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(h3, 6, 8, 1, 1);

        a5 = new Case(gridLayoutWidget);
        a5->setObjectName("a5");
        sizePolicy.setHeightForWidth(a5->sizePolicy().hasHeightForWidth());
        a5->setSizePolicy(sizePolicy);
        a5->setStyleSheet(QString::fromUtf8("background:transparent;"));
        a5->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(a5, 3, 0, 1, 1);

        a7 = new Case(gridLayoutWidget);
        a7->setObjectName("a7");
        sizePolicy.setHeightForWidth(a7->sizePolicy().hasHeightForWidth());
        a7->setSizePolicy(sizePolicy);
        a7->setStyleSheet(QString::fromUtf8("background:transparent;"));
        a7->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(a7, 1, 0, 1, 1);

        h2 = new Case(gridLayoutWidget);
        h2->setObjectName("h2");
        sizePolicy.setHeightForWidth(h2->sizePolicy().hasHeightForWidth());
        h2->setSizePolicy(sizePolicy);
        h2->setStyleSheet(QString::fromUtf8("background:transparent;"));
        h2->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(h2, 7, 8, 1, 1);

        d1 = new Case(gridLayoutWidget);
        d1->setObjectName("d1");
        sizePolicy.setHeightForWidth(d1->sizePolicy().hasHeightForWidth());
        d1->setSizePolicy(sizePolicy);
        d1->setStyleSheet(QString::fromUtf8("background:transparent;"));
        d1->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(d1, 8, 3, 1, 1);

        c2 = new Case(gridLayoutWidget);
        c2->setObjectName("c2");
        sizePolicy.setHeightForWidth(c2->sizePolicy().hasHeightForWidth());
        c2->setSizePolicy(sizePolicy);
        c2->setStyleSheet(QString::fromUtf8("background:transparent;"));
        c2->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(c2, 7, 2, 1, 1);

        a8 = new Case(gridLayoutWidget);
        a8->setObjectName("a8");
        sizePolicy.setHeightForWidth(a8->sizePolicy().hasHeightForWidth());
        a8->setSizePolicy(sizePolicy);
        a8->setAutoFillBackground(false);
        a8->setStyleSheet(QString::fromUtf8("background:transparent;"));
        a8->setIconSize(QSize(80, 80));

        plateauLayout->addWidget(a8, 0, 0, 1, 1);

        CompteurTour = new QLabel(centralWidget);
        CompteurTour->setObjectName("CompteurTour");
        CompteurTour->setGeometry(QRect(850, 50, 181, 61));
        CompteurTour->setStyleSheet(QString::fromUtf8("font-family:sans-serif;\n"
"\n"
"font: 25px arial bold;"));
        PartieNormaleButton = new QPushButton(centralWidget);
        PartieNormaleButton->setObjectName("PartieNormaleButton");
        PartieNormaleButton->setGeometry(QRect(900, 320, 171, 61));
        StatusLabel = new QLabel(centralWidget);
        StatusLabel->setObjectName("StatusLabel");
        StatusLabel->setGeometry(QRect(840, 210, 311, 91));
        StatusLabel->setStyleSheet(QString::fromUtf8("font-family:sans-serif;\n"
"font: 25px arial bold;"));
        posLabel = new QLabel(centralWidget);
        posLabel->setObjectName("posLabel");
        posLabel->setGeometry(QRect(850, 110, 271, 81));
        posLabel->setStyleSheet(QString::fromUtf8("font-family:sans-serif;\n"
"font: 25px arial bold;"));
        posRandomButton = new QPushButton(centralWidget);
        posRandomButton->setObjectName("posRandomButton");
        posRandomButton->setGeometry(QRect(900, 400, 171, 61));
        posRandomButton2 = new QPushButton(centralWidget);
        posRandomButton2->setObjectName("posRandomButton2");
        posRandomButton2->setGeometry(QRect(900, 480, 171, 61));
        GameWindowClass->setCentralWidget(centralWidget);
        posRandomButton2->raise();
        posRandomButton->raise();
        BoardImg->raise();
        gridLayoutWidget->raise();
        CompteurTour->raise();
        PartieNormaleButton->raise();
        StatusLabel->raise();
        gameHider->raise();
        CommencerButton->raise();
        QuitterButton->raise();
        GameTitle->raise();
        posLabel->raise();
        menuBar = new QMenuBar(GameWindowClass);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 1180, 22));
        GameWindowClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(GameWindowClass);
        mainToolBar->setObjectName("mainToolBar");
        GameWindowClass->addToolBar(Qt::ToolBarArea::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(GameWindowClass);
        statusBar->setObjectName("statusBar");
        GameWindowClass->setStatusBar(statusBar);

        retranslateUi(GameWindowClass);
        QObject::connect(CommencerButton, SIGNAL(clicked()), GameWindowClass, SLOT(commencerButton()));
        QObject::connect(QuitterButton, SIGNAL(clicked()), GameWindowClass, SLOT(quitterButton()));
        QObject::connect(PartieNormaleButton, SIGNAL(clicked()), GameWindowClass, SLOT(partieNormaleInit()));
        QObject::connect(a8, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(b8, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(c8, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(d8, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(e8, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(f8, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(g8, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(h8, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(a7, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(b7, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(c7, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(d7, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(e7, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(f7, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(g7, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(h7, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(a6, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(b6, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(c6, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(d6, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(e6, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(f6, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(g6, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(h6, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(a5, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(b5, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(c5, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(d5, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(e5, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(f5, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(g5, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(h5, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(a4, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(b4, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(c4, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(d4, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(e4, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(f4, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(g4, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(h4, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(a3, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(b3, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(c3, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(d3, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(e3, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(f3, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(g3, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(h3, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(a2, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(b2, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(c2, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(d2, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(e2, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(f2, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(g2, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(h2, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(a1, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(b1, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(c1, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(d1, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(e1, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(f1, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(g1, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(h1, SIGNAL(clicked()), GameWindowClass, SLOT(buttonPressed()));
        QObject::connect(posRandomButton, SIGNAL(clicked()), GameWindowClass, SLOT(partieRandom1Init()));
        QObject::connect(posRandomButton2, SIGNAL(clicked()), GameWindowClass, SLOT(partieRandom2Init()));

        QMetaObject::connectSlotsByName(GameWindowClass);
    } // setupUi

    void retranslateUi(QMainWindow *GameWindowClass)
    {
        GameWindowClass->setWindowTitle(QCoreApplication::translate("GameWindowClass", "GameWindow", nullptr));
        BoardImg->setText(QString());
        gameHider->setText(QCoreApplication::translate("GameWindowClass", "TextLabel", nullptr));
        GameTitle->setText(QCoreApplication::translate("GameWindowClass", "Jeu \303\211checs.", nullptr));
        CommencerButton->setText(QCoreApplication::translate("GameWindowClass", "Commencer", nullptr));
        QuitterButton->setText(QCoreApplication::translate("GameWindowClass", "Quitter", nullptr));
        g7->setText(QString());
        a6->setText(QString());
        c3->setText(QString());
        d4->setText(QString());
        e8->setText(QString());
        h7->setText(QString());
        e6->setText(QString());
        a3->setText(QString());
        g4->setText(QString());
        f6->setText(QString());
        h4->setText(QString());
        g2->setText(QString());
        g1->setText(QString());
        g3->setText(QString());
        b3->setText(QString());
        b7->setText(QString());
        d6->setText(QString());
        d2->setText(QString());
        d8->setText(QString());
        f1->setText(QString());
        b2->setText(QString());
        f3->setText(QString());
        f8->setText(QString());
        e3->setText(QString());
        a1->setText(QString());
        d3->setText(QString());
        c1->setText(QString());
        b8->setText(QString());
        g5->setText(QString());
        g6->setText(QString());
        f5->setText(QString());
        c6->setText(QString());
        g8->setText(QString());
        e5->setText(QString());
        f4->setText(QString());
        f2->setText(QString());
        h1->setText(QString());
        e4->setText(QString());
        h6->setText(QString());
        c7->setText(QString());
        b1->setText(QString());
        c4->setText(QString());
        e1->setText(QString());
        e7->setText(QString());
        a4->setText(QString());
        c5->setText(QString());
        b6->setText(QString());
        e2->setText(QString());
        a2->setText(QString());
        d5->setText(QString());
        c8->setText(QString());
        b4->setText(QString());
        b5->setText(QString());
        d7->setText(QString());
        h8->setText(QString());
        h5->setText(QString());
        f7->setText(QString());
        h3->setText(QString());
        a5->setText(QString());
        a7->setText(QString());
        h2->setText(QString());
        d1->setText(QString());
        c2->setText(QString());
        a8->setText(QString());
        CompteurTour->setText(QCoreApplication::translate("GameWindowClass", "Blanc \303\240 jouer", nullptr));
        PartieNormaleButton->setText(QCoreApplication::translate("GameWindowClass", "Partie Normale", nullptr));
        StatusLabel->setText(QString());
        posLabel->setText(QString());
        posRandomButton->setText(QCoreApplication::translate("GameWindowClass", "Position Random", nullptr));
        posRandomButton2->setText(QCoreApplication::translate("GameWindowClass", "Position Random 2", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GameWindowClass: public Ui_GameWindowClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GAMEWINDOW_H
