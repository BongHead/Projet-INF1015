﻿# Projet-INF1015

# Jeu échecs

par Song Ning Lan (2295538) et Sheng He Ge (2290577)


### Projet final du cours INF-1015.
#### Inspiré le moins possible des ressources extérieures, donc peut être un peu lourd à lire.