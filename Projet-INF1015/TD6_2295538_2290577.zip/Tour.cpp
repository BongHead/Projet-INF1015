#include "Tour.hpp"


Tour::Tour(int x, int y, Couleur couleur) : Piece(x,y,couleur, Piece::Tour) {

}