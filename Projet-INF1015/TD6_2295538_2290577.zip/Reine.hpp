#pragma once
#include "Piece.hpp"


class Reine : public Piece {
public:
	Reine();
protected:

private:

};
