#include "Cavalier.hpp"



Cavalier::Cavalier(int x, int y, Couleur couleur) : Piece(x, y, couleur, Piece::Cavalier) {

}