#pragma once
#include "Piece.hpp"



class Tour : public Piece {
public:
	Tour(int x, int y, Couleur couleur);
protected:

private:

};