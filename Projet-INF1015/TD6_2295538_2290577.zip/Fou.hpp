#pragma once
#include "Piece.hpp"



class Fou : public Piece {
public:
	Fou();
protected:

private:

};