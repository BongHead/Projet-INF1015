#include "Fou.hpp"


Fou::Fou() {

}