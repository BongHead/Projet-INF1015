#pragma once
#include <iostream>


#include <QtWidgets/QMainWindow>
#include "ui_GameWindow.h"
#include <QPixmap>
#include <QMessageBox>
#include "Plateau.hpp"

namespace front_end {
    class GameWindow : public QMainWindow
    {
        Q_OBJECT

    public:
        GameWindow(QWidget *parent = nullptr);
        ~GameWindow();
        back_end::Plateau* plateau;
    signals:

    public slots:
        void commencerButton();
        void quitterButton();
        //void testBouton();
        void partieNormaleInit();
        //void jouer(int x, int y);
        void syncPlateau();
        static string posToObjName(int x, int y);
    private:
        //void assignerPos();
        
        Ui::GameWindowClass ui;
    
    };
}
