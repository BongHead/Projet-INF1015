#pragma once
#include "Piece.hpp"

class Cavalier : public Piece {
public:
	Cavalier(int x, int y, Couleur couleur);
protected:

private:

};