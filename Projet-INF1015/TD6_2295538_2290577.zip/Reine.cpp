#include "Reine.hpp"


Reine::Reine() {

}